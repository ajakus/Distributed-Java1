package edu.wctc.dice.iface;

public interface GameInput {
    String getInput(String prompt);
}
