package edu.wctc.dice.iface;

public interface GameOutput {
    void output(String text);
}
