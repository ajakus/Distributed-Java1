package edu.wctc.dice.iface;

public interface DieRoller {
    private int rollDie();
}
